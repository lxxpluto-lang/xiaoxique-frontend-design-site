export type ActivityId = 'baduanjin' | 'resistance' | 'singing'

export interface RiveMotionAsset {
  src: string
  artboard: string
  stateMachine: 'Motion Machine'
  fit: 'contain' | 'cover'
  placement: 'card' | 'page'
  enabled: boolean
}

export interface Activity {
  id: ActivityId
  title: string
  shortTitle: string
  icon: string
  duration: string
  cue: string
  video: string
  poster: string
  rive: RiveMotionAsset
}

/**
 * Rive V3 runtime contract.
 *
 * Keep `enabled` false until the corresponding binary has been exported from
 * Rive Desktop and validated. This prevents a missing or placeholder .riv
 * from silently replacing the working MP4 preview.
 */
export const activities: Activity[] = [
  {
    id: 'baduanjin',
    title: '舒缓八段锦',
    shortTitle: '八段锦',
    icon: '伸',
    duration: '3 分钟',
    cue: '跟着翅膀缓缓抬起，呼吸不要憋住',
    video: '/static/videos/magpie-baduanjin-cinematic-v2.mp4',
    poster: '/static/frames/baduanjin-cinematic-v2/01.png',
    rive: {
      src: '/static/rive/magpie-baduanjin-v3.riv',
      artboard: 'Baduanjin',
      stateMachine: 'Motion Machine',
      fit: 'contain',
      placement: 'card',
      enabled: false,
    },
  },
  {
    id: 'resistance',
    title: '趣味抗阻运动',
    shortTitle: '抗阻运动',
    icon: '蹲',
    duration: '2 分钟',
    cue: '稳稳浅蹲，托住小喜鹊起跳和落下',
    video: '/static/videos/magpie-resistance-cinematic-v2.mp4',
    poster: '/static/frames/resistance-cinematic-v2/01.png',
    rive: {
      src: '/static/rive/magpie-resistance-v3.riv',
      artboard: 'Resistance',
      stateMachine: 'Motion Machine',
      fit: 'contain',
      placement: 'card',
      enabled: false,
    },
  },
  {
    id: 'singing',
    title: '开心唱一唱',
    shortTitle: '唱歌',
    icon: '♪',
    duration: '1 分钟',
    cue: '轻轻哼唱，让肩膀和心情一起放松',
    video: '/static/videos/magpie-singing-cinematic-v2.mp4',
    poster: '/static/frames/singing-cinematic-v2/01.png',
    rive: {
      src: '/static/rive/magpie-singing-v3.riv',
      artboard: 'SingingScreenBreak',
      stateMachine: 'Motion Machine',
      fit: 'cover',
      placement: 'page',
      enabled: false,
    },
  },
]

export const riveInputs = {
  play: 'play',
  replay: 'replay',
  celebrate: 'celebrate',
  reducedMotion: 'reducedMotion',
} as const
